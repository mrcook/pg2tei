#!/usr/bin/perl
#
# This utility will create a BAT file of all the files in a dir
# and create the TEI files from this list of TXT files.

require 5.004;
use strict;


### GET FILES in directory #############################
my $dir = "G:";
opendir(DH, $dir) or die "Couldn't open $dir for reading: $!";
my $file = "";
my @source_files = ();
while( defined ($file = readdir DH ) ) {
next unless ($file =~ /\.txt/);
my $filename = "$dir/$file";
 push(@source_files, $filename);
# print $file . "\n";
}
closedir(DH);

### end of GET FILES ###################################

##########################
### Write the BAT file ###
##########################

# Write the BAT file
open (FILEOUT, "> pg2tei.bat") or die "Couldn't open $dir for writing: $!";

foreach $file(@source_files) {
$file =~ s|^(.*)txt$|perl \-w $dir/pg2tei\.pl $1txt > $1tei\n|;
print FILEOUT $file;
}

close FILEOUT;


# Local Variables:
# mode:perl
# coding:iso-8859-1-unix
# End:

