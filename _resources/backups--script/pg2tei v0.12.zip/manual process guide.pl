THINGS TO CHECK
---------------

Fix up the Front matter section and make sure all is Tagged correctly.

<head>   - Check that head's, div's, etc, are correct
            if not then it may be worth adjusting the origianl txt
            to fix any CHAPTER spacings. Best is 3 / 2.

<figure - CHECK all figures and correct the path/filename

[       - FOOTNOTE
*       - FOOTNOTE

LoC Class

^[sp]   - CHECK Indents on Original TXT file.

---------------------------------------

Footnotes

<note place="foot">

[PLACE FOOTNOTE HERE]

</note>

--

<quote>

 rend="margin-left: 2"


<lg rend="margin-left: 10%">
<l></l>
<l></l>
</lg>


<lg rend="margin-left: 10%">
<l><q rend="pre"></q></l>
<l><q rend="post"></q></l>
</lg>


  <div type="figures">
    <index index="pdf"/>
    <head>Illustrations</head>
    <divGen type="fig"/>
  </div>

<milestone unit="tb" />
--

Grab the LoC Class from the PG website.
e.g.
            The Time Machine - H.G. Wells
LoC Class:  PR: Language and Literatures: English literature


----

</div>

</div>


<div type="book" n="2">

<index index="toc" />
<index index="pdf" />

<head>BOOK THE SECOND - REAPING</head>